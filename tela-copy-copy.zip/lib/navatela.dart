import 'package:flutter/material.dart';

class NovaTela extends StatelessWidget {
  const NovaTela({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Seja bem vindo !',
                style: TextStyle(fontSize: 28, color: Color(0xFFE05D5D)),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                height: 30,
                decoration: const BoxDecoration(color: Colors.white),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: Colors.white),
                  child: const Text(
                    'Next',
                    style: TextStyle(color: Color(0xFFE05D5D), fontSize: 15),
                  ),
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
