import 'package:flutter/material.dart';
import 'package:tela/splash.dart';
import 'package:tela/telaCadastro.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/telaCadastro',
      routes: {
        '/telaCadastro': (_) => TelaCadastro(),
        '/splash': (_) => Splash(),
      },
    );
  }
}
