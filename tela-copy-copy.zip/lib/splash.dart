import 'package:flutter/material.dart';
import 'package:tela/navatela.dart';
import 'dart:async';

class Splash extends StatefulWidget {
  const Splash({super.key});
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(Duration(seconds: 10), () {
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NovaTela(),
          ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Criando usuario...',
                style: TextStyle(
                    color: Color(0xFFE05D5D),
                    fontSize: 22.00,
                    fontWeight: FontWeight.bold)),
            SizedBox(
              height: 7.0,
            ),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(Color(0xFFE05D5D)),
              strokeWidth: 10.00,
            )
          ],
        ),
      ),
    );
  }
}
