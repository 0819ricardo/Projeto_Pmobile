package com.example.tela

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
